package se201.shruthi;

import java.io.FileReader;
import java.io.IOException;
import java.math.BigDecimal;
import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.SQLException;
import java.sql.Timestamp;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.List;
import java.util.function.BooleanSupplier;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;

public class LoadDataIntoDatabase {

    public static void main(String[] args) throws SQLException, IOException, ParseException, org.json.simple.parser.ParseException {
        String jsonFilePath = ".\\jsonfiles\\filters.json";

        // Credentials for Database connection
        String Url = "jdbc:oracle:thin:@//localhost:1521/orcl";
        String Username = "system";
        String Password = "Smqa1234@";

        // connecting to database
        try (Connection Connection = DriverManager.getConnection(Url, Username, Password);
             FileReader reader = new FileReader(jsonFilePath)) {

            // Parsing JSON data
            JSONParser jsonParser = new JSONParser();
            Object obj = jsonParser.parse(reader); //reading JSON data
            JSONObject jsonObject = (JSONObject) obj;

            JSONArray videosArray = (JSONArray) jsonObject.get("videos");

            // Iterates through JSON array and insert data into databases
            for (Object videoObj : videosArray) {
                JSONObject video = (JSONObject) videoObj;                
                insertVideoData(Connection, video);
            }
            System.out.println("Data inserted into databases.");
        } 
        catch (SQLException e) {
            e.printStackTrace();
        }
    }
    
    // Passing JSON values into database in a sequence

    private static void insertVideoData(Connection connection, JSONObject video) throws SQLException {
        String sql = "INSERT INTO youtube_videos (video_id, video_title, published_at, video_duration, view_count, like_count, dislike_count, favorite_count, comment_count, channel_id, channel_title, commentID, comments) " +
                "VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)";

        try (PreparedStatement preparedStatement = connection.prepareStatement(sql)) {
            preparedStatement.setString(1, (String) video.get("videoId"));
            preparedStatement.setString(2, (String) video.get("videoTitle"));
            preparedStatement.setTimestamp(3, convertStringToTimestamp((String) video.get("publishedAt")));
            preparedStatement.setString(4, (String) video.get("videoDuration"));
            preparedStatement.setBigDecimal(5, BigDecimal.valueOf((Long) video.get("viewCount")));
            preparedStatement.setBigDecimal(6, BigDecimal.valueOf((Long) video.get("likeCount")));
            preparedStatement.setBigDecimal(7, BigDecimal.valueOf((Long) video.get("dislikeCount")));
            preparedStatement.setBigDecimal(8, BigDecimal.valueOf((Long) video.get("favoriteCount")));
            preparedStatement.setBigDecimal(9, BigDecimal.valueOf((Long) video.get("commentCount")));
            preparedStatement.setString(10, (String) video.get("channelId"));
            preparedStatement.setString(11, (String) video.get("channelTitle"));
            preparedStatement.setString(12, (String) video.get("commentId"));

            JSONArray commentsArray = (JSONArray) video.get("comments");
            preparedStatement.setString(13, convertCommentsListToString(commentsArray));

            preparedStatement.executeUpdate();
        }
    }
    
    // type conversion for Timestamp datatype in database

    private static Timestamp convertStringToTimestamp(String dateString) {
        try {
            java.util.Date date = new SimpleDateFormat("yyyy-MM-dd'T'HH:mm:ss'Z'").parse(dateString);
            return new Timestamp(date.getTime());
        } catch (ParseException e) {
            e.printStackTrace();
            return null;
        }
    }
    
    //adding list of comments in a database comments column

    private static String convertCommentsListToString(List<String> comments) {
        return String.join(", ", comments);
    }
//
	public static BooleanSupplier loadData() {
		
		return null;
	}
}

