package se201.shruthi;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.function.BooleanSupplier;


public class DatabaseBackup {

    public static void main(String[] args) {
        // Database connection details for export
        String exportUsername = "system";
        String exportPassword = "Smqa1234@";
        String exportConnectionString = "//localhost:1521/orcl";
        String exportDirectory = "C:\\backup";
        String exportDumpfile = "backup.dmp";

        // Database export
        performDatabaseExport(exportUsername, exportPassword, exportConnectionString, exportDirectory, exportDumpfile);
    }

    private static void performDatabaseExport(String username, String password, String connectionString, String directory, String dumpfile) {
        try {
            // Building the expdp command
            ProcessBuilder processBuilder = new ProcessBuilder(
                    "expdp", username + "/" + password + "@" + connectionString,
                    "schemas=" + username,
                    "directory=" + directory,
                    "dumpfile=" + dumpfile );

            // Redirecting error to output stream
            processBuilder.redirectErrorStream(true);

            // Start the process
            Process process = processBuilder.start();

            // Captures the process output
            try (BufferedReader reader = new BufferedReader(new InputStreamReader(process.getInputStream()))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    System.out.println(line);
                }
            }

            // Waits for the process to finish
            int exitCode = process.waitFor();

            // Checks the exit code
            if (exitCode == 0) {
                System.out.println("Database export completed successfully.");
            } 
            else {
                System.err.println("Error during database export. Exit code: " + exitCode);
            }
        } 
        catch (IOException | InterruptedException e) {
            e.printStackTrace();
        }
    }
//
	public static BooleanSupplier performDatabaseExport() {
		
		return null;
	}
}

