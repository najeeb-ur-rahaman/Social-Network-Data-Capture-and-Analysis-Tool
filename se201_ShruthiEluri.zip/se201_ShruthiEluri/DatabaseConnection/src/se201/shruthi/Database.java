package se201.shruthi;
import java.sql.*;
import java.util.function.BooleanSupplier;

public class Database {

    public static void main(String args[]) throws SQLException {

        // Credentials for database connection
        String Url = "jdbc:oracle:thin:@//localhost:1521/orcl";
        String Username = "system";
        String Password = "Smqa1234@";       

        // SQL query for creating youtube_videos table
        String createTableSql = "CREATE TABLE youtube_videos ("
                + "video_id VARCHAR(11) PRIMARY KEY NOT NULL, "
                + "video_title VARCHAR(100) NOT NULL, "
                + "published_at TIMESTAMP NOT NULL, "
                + "video_duration VARCHAR(8) NOT NULL, "
                + "channel_id VARCHAR(24) NOT NULL, "
                + "channel_title VARCHAR(100) NOT NULL, "
                + "like_count DECIMAL, "
                + "dislike_count DECIMAL, "
                + "favorite_count DECIMAL, "
                + "view_count DECIMAL,"
                + "commentID VARCHAR(50) UNIQUE NOT NULL, "
                + "comment_count DECIMAL, "
                + "comments VARCHAR(2000))";
        
        Connection Connection = null;        
        Statement Statement = null;
        
        try {
            // Establish a connection to database
            Connection = DriverManager.getConnection(Url, Username, Password);
            System.out.println("Connection established to system database.");

            // Create a statement object for database
            Statement = Connection.createStatement();

            // Execute statement to create table
            Statement.execute(createTableSql);
            System.out.println("Table 'youtube_videos' created in system database.");                       
        }        
        catch (SQLException e) {
            e.printStackTrace();
            
        } 
        finally {
            // Closing resources
            if (Statement != null)
                Statement.close();
            System.out.println("statement closed.");
            if (Connection != null)
                Connection.close();
            System.out.println("connection closed.");

            
        }
    }
//
	public static BooleanSupplier createDatabase() {
		
		return null;
	}
}
