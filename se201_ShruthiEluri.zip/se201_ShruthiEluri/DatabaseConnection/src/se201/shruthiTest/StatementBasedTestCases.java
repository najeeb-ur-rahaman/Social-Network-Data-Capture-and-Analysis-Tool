package se201.shruthiTest;



import org.junit.jupiter.api.Test;
import se201.shruthi.Database;
import se201.shruthi.DatabaseBackup;
import se201.shruthi.LoadDataIntoDatabase;

import static org.junit.jupiter.api.Assertions.*;

public class StatementBasedTestCases {

    @Test
    void testDatabaseTableCreation() {
        // Test Case for checking 'youtube_videos' table is created in database
        assertDoesNotThrow(() -> Database.main(null), "Exception occurred while creating table");
    }

    @Test
    void testLoadDataIntoDatabase() {
        // Test Case for data is loaded into 'youtube_videos' table
        assertDoesNotThrow(() -> LoadDataIntoDatabase.main(null), "Exception occurred while loading data into database");
    }

    @Test
    void testPerformDatabaseExport() {
        // Test Case for database export process is running without errors
        assertDoesNotThrow(() -> DatabaseBackup.main(new String[]{}), "Exception occurred during database export");
    }

    @Test
    void testDatabaseConnectionEstablishment() {
        // Test Case for successful database connection
        assertDoesNotThrow(() -> Database.main(null), "Exception occurred while establishing a database connection");
    }

    @Test
    void testLoadDataIntoDatabaseWithInvalidJson() {
        // Test Case for checking exception is thrown or not when loading data with an invalid JSON file
        assertThrows(org.json.simple.parser.ParseException.class, () -> LoadDataIntoDatabase.main(new String[]{"invalid_json_file"}), "Invalid JSON file did not throw the expected exception");
    }
 
}

