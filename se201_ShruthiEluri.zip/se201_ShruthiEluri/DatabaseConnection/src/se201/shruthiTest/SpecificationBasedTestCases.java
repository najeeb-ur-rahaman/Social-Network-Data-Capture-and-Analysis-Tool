package se201.shruthiTest;

import static org.junit.Assert.*;
import org.junit.Test;
import se201.shruthi.DatabaseBackup;
import se201.shruthi.LoadDataIntoDatabase;
import java.sql.*;
import java.text.ParseException;
import java.io.*;

public class SpecificationBasedTestCases {

    @Test
    public void testDatabaseConnection() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl", "system", "Smqa1234@");
            assertNotNull("Connection should not be null", connection);
            assertTrue("Connection should be open", connection.isValid(5));
            connection.close();
            assertFalse("Connection should be closed", connection.isValid(5));
        } catch (SQLException e) {
            fail("Exception thrown while testing database connection: " + e.getMessage());
        }
    }

    @Test
    public void testTableCreation() {
        try {
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl", "system", "Smqa1234@");
            Statement statement = connection.createStatement();
            assertTrue("Table 'youtube_videos' should exist", statement.execute("SELECT * FROM youtube_videos WHERE 1 = 0"));
            connection.close();
        } catch (SQLException e) {
            fail("Exception thrown while testing table creation: " + e.getMessage());
        }
    }

    @Test
    public void testJsonFileReading() {
        try {
            FileReader reader = new FileReader(".\\jsonfiles\\filters.json");
            assertNotNull("Reader should not be null", reader);
            reader.close();
        } catch (IOException e) {
            fail("Exception thrown while testing JSON file reading: " + e.getMessage());
        }
    }

    @Test
    public void testDataInsertion() throws SQLException, IOException, ParseException, org.json.simple.parser.ParseException {
        try {
            LoadDataIntoDatabase.main(null); 
            
            Connection connection = DriverManager.getConnection("jdbc:oracle:thin:@//localhost:1521/orcl", "system", "Smqa1234@");
            Statement statement = connection.createStatement();
            ResultSet resultSet = statement.executeQuery("SELECT COUNT(*) FROM youtube_videos");
            assertTrue("At least one row should be inserted", resultSet.next() && resultSet.getInt(1) > 0);
            connection.close();
        } finally {
            Throwable e = null;
			fail("Exception thrown while testing data insertion: " + e.getMessage());
        }
    }

    @Test
    public void testDatabaseExport() {
        try {
            DatabaseBackup.main(null); 
            
            File backupFile = new File("C:\\backup\\backup.dmp");
            assertTrue("Backup file should exist", backupFile.exists());
        } catch (Exception e) {
            fail("Exception thrown while testing database export: " + e.getMessage());
        }
    }
}
