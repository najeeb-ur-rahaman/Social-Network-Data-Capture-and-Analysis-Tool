package se201.shruthiTest;

import static org.junit.Assert.assertThrows;
import java.io.IOException;
import java.sql.SQLException;
import java.text.ParseException;

import org.junit.jupiter.api.Test;
import se201.shruthi.Database;
import se201.shruthi.LoadDataIntoDatabase;
import se201.shruthi.DatabaseBackup;

public class MutationTestCases {

    @Test
    void testIncorrectColumnType() {
        
        assertThrows(SQLException.class, () -> {
            Database.main(null);
        });
    }

    @Test
    void testIncorrectTimestampFormat() {
       
        assertThrows(ParseException.class, () -> {
            LoadDataIntoDatabase.main(null);
        });
    }

    @Test
    void testIncorrectBackupDirectory() {
        
        assertThrows(IOException.class, () -> {
            DatabaseBackup.main(null);
        });
    }

    @Test
    void testIncorrectJsonFilePath() {
        
        assertThrows(SQLException.class, () -> {
            LoadDataIntoDatabase.main(null);
        });
    }

    @Test
    void testIncorrectDumpfileName() {
        
        assertThrows(IOException.class, () -> {
            DatabaseBackup.main(null);
        });
    }
}
