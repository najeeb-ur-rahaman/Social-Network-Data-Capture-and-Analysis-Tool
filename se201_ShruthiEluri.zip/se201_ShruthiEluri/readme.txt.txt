import DatabaseConnection folder in eclipse
for test cases run and code coverage screenshots are provided in Test cases folder
for importing JAR files, refer to jar files folder in the zip file
to run code: run as java application
for test cases and code coverage: coverage as junit

for database connection:
download and install sql developer for seeing tables and data in the database
https://www.oracle.com/database/sqldeveloper/technologies/download/
use host as 127.0.0.1
	Url = "jdbc:oracle:thin:@//localhost:1521/orcl";
	Username = system
	Password = Smqa1234
	host: 192.168.0.101
	port: 1521
	ServiceName: orcl

Download Oracle database software for Run Oracle Database 21c XE on Windows
https://www.oracle.com/database/technologies/oracle-database-software-downloads.html

